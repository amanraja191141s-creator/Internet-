# Changelog — v98.63.9.21

- Reworked the Tools landing screen to match the supplied Android recording: title/back header, grouped sections, compact three-column category tiles, and independent vertical scrolling.
- Reorganized available tool destinations into Finance & Money, Math & General Utilities, and Health groups. All cards route through the existing screen navigation; event delegation now covers every group rather than only the first grid.
- Added a Unit Converter category landing screen with the reference three-column layout. The conversion form opens only after a category is selected and includes a back-to-category action.
- Added Current and Voltage categories with ampere/milliampere/microampere/kiloampere and millivolt/volt/kilovolt conversion factors.
- Kept existing converter calculation, numeric keypad, currency screen, calculator, scientific drawer, and existing tool screens intact.
- Updated app identity to 1.98.69-v98.63.9.21 (Android versionCode 1098069), service-worker cache namespace, and Android Actions workflow.
- Added four focused regression tests for grouped Tools navigation, three-column layouts, Unit Converter category routing, and Current/Voltage factors.

## Scope note
The supplied recording shows Salary and SIP cards. The v98.63.9.20 source does not contain dedicated Salary or SIP calculator screens, so this release does not misroute those labels to unrelated calculators or present non-working cards. Those features need separate calculator implementations before they can be exposed as functional destinations.
