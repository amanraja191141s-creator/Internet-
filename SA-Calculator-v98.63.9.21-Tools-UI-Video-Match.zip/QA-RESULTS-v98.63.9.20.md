# QA results — v98.63.9.20

## Automated verification
- Release regression suite: **35/35 passed, 0 failed**.
- JavaScript syntax (`assets/js/app.js`, generated `www/assets/js/app.js`): PASS.
- Service worker syntax (source and generated bundle): PASS.
- Android web bundle: PASS — 13 required assets verified.
- GitHub Actions YAML parse: PASS.
- ZIP integrity: PASS.
- Release identity: `1.98.68-v98.63.9.20`; Android workflow versionCode `1098068`.

## Video-derived interaction checks
- Scientific drawer overlays only the main keypad band; it does not cover the main display.
- Normal keypad stays full width; no 46/54 split or shrink is applied.
- Drawer width is 90% (92% on narrow phones), matching the reference's narrow exposed keypad strip.
- Pointer drag updates the drawer position continuously; release settles by distance or velocity.
- Reverse swipe closes the drawer; Escape and close control remain available.
- Scientific 4×4 function matrix and shared-expression insertion are covered by release tests.

## Not yet device-certified
Physical Android installation, OEM gesture-conflict behaviour, real touch latency/frame pacing, and pixel comparison on the user's handset still require a fresh APK run on the device. These are not represented as passed by source-level tests.
