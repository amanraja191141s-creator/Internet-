# Micro-level audit — v98.63.9.17

## Screenshot comparison
- Previous build used 53% display / 47% keypad, making the display too tall and keypad rows too short.
- Reference screenshot measures approximately 36% display / 64% keypad within the area between status and bottom navigation.
- New layout uses 36:64 portrait split; compact-height screens use 34:66.
- Keys fill 95% width and 96% height of grid cells; zero spans two columns at 97%.

## Typography policy
- Editable expression: 30px maximum, 18px minimum. It shrinks only when measured width exceeds available width; below the floor, the input remains horizontally scrollable and caret-safe.
- Live preview: 56px maximum, 22px minimum. Binary-search fit chooses the largest size that fits; scientific display compaction is used only after the minimum size cannot fit.
- Committed result: 64px maximum, 22px minimum, with the same measured-width fitting and display-only scientific fallback.
- Canonical expression/result values and arithmetic precision are unchanged.
- ResizeObserver, viewport resize, orientation, and font-ready events continue to schedule fitting.

## Research boundary
Publicly available product documentation does not publish a common exact dp/sp threshold table for 20+ calculator apps. The implementation therefore follows documented patterns rather than inventing competitor-specific measurements: Google AOSP uses variable text sizing and reduces the result to the formula's fitted size; ASUS explicitly documents auto-adjusting font size to fit more digits; HiPER exposes display font-size controls; Android guidance recommends responsive content that does not clip at larger text settings.

## Validation
- Existing regression suite plus new v98.63.9.17 tests.
- Android WebView installation and visual pixel comparison remain device-side checks.

## Public reference material consulted
- Google Calculator redesign: https://9to5google.com/2025/08/22/google-calculator-material-3-expressive/
- Android Open Source Project variable formula/result sizing: https://android.googlesource.com/platform/packages/apps/ExactCalculator/+/1a428cf/src/com/android/calculator2/Calculator.java
- ASUS Calculator auto-adjusts display font size: https://play.google.com/store/apps/details?id=com.asus.calculator
- HiPER display-size/font-size settings: https://www.hipercalc.app/help.html
- Android responsive text guidance: https://support.google.com/accessibility/android/answer/12159181
- Apple Calculator behavior and display controls: https://support.apple.com/en-mide/guide/iphone/iph1ac0b5cc/ios

These sources establish adaptive fitting, readable typography and responsive layout patterns. They do not publish a common numerical font-size threshold table for 20+ competitor apps; exact per-app px values are not publicly documented, so no such table is fabricated.
