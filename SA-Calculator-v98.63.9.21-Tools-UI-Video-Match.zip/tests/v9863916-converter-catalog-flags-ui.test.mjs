import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
const root = path.resolve(import.meta.dirname || path.dirname(new URL(import.meta.url).pathname), '..');
const js = fs.readFileSync(path.join(root, 'assets/js/app.js'), 'utf8');
const css = fs.readFileSync(path.join(root, 'assets/css/app.css'), 'utf8');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');

test('currency and unit picker render every enabled option before search is used', () => {
  assert.match(js, /Every enabled option is present on first open/);
  assert.doesNotMatch(js, /revealAlternatives/);
  assert.doesNotMatch(js, /query\.length < 2 && index !== selectedIndex/);
  assert.match(js, /if \(query && !\(optionLabel \+ ' ' \+ option\.value\)\.toLocaleLowerCase\(\)\.includes\(query\)\) return;/);
});

test('currency picker rows include country flag, localized name, ISO code and region', () => {
  assert.match(js, /currencyFlagForCode\(code\)/);
  assert.match(js, /localizedCurrencyName\(code\)/);
  assert.match(js, /currencyRegionNameForCode\(code\)/);
  assert.match(js, /is-currency-option/);
  assert.match(css, /\.sumaire-picker-option-flag/);
  assert.match(css, /Noto Color Emoji/);
  assert.match(css, /\.sumaire-select-trigger \.sumaire-select-flag/);
});

test('unit picker rows use full-width label column rather than an empty flag column', () => {
  assert.match(js, /is-unit-option/);
  assert.match(css, /\.sumaire-picker-option\.is-unit-option\s*\{\s*grid-template-columns:minmax\(0,1fr\) 22px/);
});

test('selected currency flag uses the visible generated selector trigger', () => {
  assert.match(html, /id="cur-from-flag"/);
  assert.match(html, /id="cur-to-flag"/);
  assert.match(js, /flagNode\.className = 'sumaire-select-flag'/);
  assert.match(css, /\.sumaire-select-trigger \.sumaire-select-flag/);
});

test('picker search is visible on open and options remain independently scrollable', () => {
  assert.match(js, /searchWrap\) searchWrap\.hidden = !searchableSelection/);
  assert.match(css, /overflow-y:auto!important/);
  assert.match(css, /max-height:min\(84dvh/);
});
