import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
const root = process.cwd();
const html = fs.readFileSync(path.join(root,'index.html'),'utf8');
const js = fs.readFileSync(path.join(root,'assets/js/app.js'),'utf8');
const css = fs.readFileSync(path.join(root,'assets/css/app.css'),'utf8');
test('Tools landing uses grouped Other Calculator hierarchy from supplied video',()=>{
  for (const label of ['Other Calculator','Finance &amp; Money','GST/VAT','Loan','Saving','Tip','Currency','Discount','Math &amp; General Utilities','Percentage','Health','Age &amp; BMI']) assert.ok(html.includes(label),`missing ${label}`);
  assert.match(html,/tools-reference-grid/);
  assert.match(css,/#screen-tools \.tools-reference-grid\s*\{[\s\S]*repeat\(3,minmax\(0,1fr\)\)/);
});
test('Every Tools category card is delegated from the whole Tools screen',()=>{
  assert.match(js,/toolsRoot\?\.addEventListener\('click',[\s\S]*toolsRoot\.contains\(card\)/);
});
test('Unit Converter opens a visible 3-column category landing before its calculator form',()=>{
  for (const [id,label] of [['mass','Weight'],['length','Length'],['area','Area'],['time','Time'],['volume','Volume'],['temperature','Temperature'],['speed','Speed'],['data','Data'],['power','Power'],['current','Current'],['voltage','Voltage']]) {
    assert.ok(html.includes(`data-unit-category="${id}"`),`missing ${label}`);
  }
  assert.match(css,/#screen-units \.unit-category-grid\s*\{[\s\S]*repeat\(3,minmax\(0,1fr\)\)/);
  assert.match(js,/function initUnits\(\)[\s\S]*showUnitCategories\(\)/);
});
test('Current and voltage have real conversion factors and selector options',()=>{
  assert.match(js,/current:\s*\{\s*base:\s*'A'/);
  assert.match(js,/voltage:\s*\{\s*base:\s*'V'/);
  assert.match(html,/<option value="current">Current<\/option>/);
  assert.match(html,/<option value="voltage">Voltage<\/option>/);
});
