# QA results — v98.63.5

- Automated regression suite: **364 passed, 0 failed** (`npm test`).
- Android web bundle: **passed** (`npm run build:web`; 34 required assets verified; 22 CSS source layers consolidated).
- JavaScript syntax: **passed** (`node --check assets/js/app.js`).
- Production copy consistency: **passed** (`index.html`, `assets/js/app.js`, and CSS source/build copies synchronized by the web build).
- Workflow YAML: **passed** (GitHub Actions workflow parses as YAML).
- ZIP integrity: **passed** (`unzip -t`).

Focused v98.63.5 regression coverage:
1. Currency picker does not automatically focus the search input, preventing the Android soft keyboard from opening merely because the picker was opened.
2. Currency option controls are full-width, vertically stacked, independently scrollable rows with bounded text.
3. Currency Converter has no redundant manual Convert button. Amount keypad edits, currency selection changes, swaps and normal recalculation paths continue to invoke `calcCurrency()`.
4. The exchange-rate card keeps its primary quote visible and hides duplicate refresh/status lines visually while preserving live status nodes for assistive technology.
5. The five-item bottom navigation is laid out consistently across screens and reserves Android bottom safe-area space once, with the dock background extending through that inset.

Physical Android validation remains required to verify WebView inset behavior, keyboard behavior, live provider responses, and exact rendering on the target device. No claim of device-level zero bugs or lag-free performance is made before that test.
